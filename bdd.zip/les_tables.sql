-- MySQL Workbench Forward Engineering

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='TRADITIONAL,ALLOW_INVALID_DATES';

-- -----------------------------------------------------
-- Schema colloque
-- -----------------------------------------------------

-- -----------------------------------------------------
-- Schema colloque
-- -----------------------------------------------------
CREATE SCHEMA IF NOT EXISTS `colloque` DEFAULT CHARACTER SET utf8 ;
USE `colloque` ;

-- -----------------------------------------------------
-- Table `colloque`.`departements`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `colloque`.`departements` ;

CREATE TABLE IF NOT EXISTS `colloque`.`departements` (
  `idDepartement` CHAR(3) NOT NULL,
  `Nom` VARCHAR(45) NOT NULL,
  `Prefecture` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`idDepartement`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `colloque`.`villes`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `colloque`.`villes` ;

CREATE TABLE IF NOT EXISTS `colloque`.`villes` (
  `idVille` SMALLINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `Cp` CHAR(5) BINARY NOT NULL,
  `Nom` VARCHAR(45) NOT NULL,
  `idDepartement` CHAR(3) NOT NULL,
  PRIMARY KEY (`idVille`),
  CONSTRAINT `fk_villes_departements`
    FOREIGN KEY (`idDepartement`)
    REFERENCES `colloque`.`departements` (`idDepartement`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;

CREATE INDEX `fk_villes_departements_idx` ON `colloque`.`villes` (`idDepartement` ASC);


-- -----------------------------------------------------
-- Table `colloque`.`etablissements`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `colloque`.`etablissements` ;

CREATE TABLE IF NOT EXISTS `colloque`.`etablissements` (
  `idEtablissement` SMALLINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `Nom` VARCHAR(30) NOT NULL,
  `Adresse` VARCHAR(45) NULL,
  `idVille` SMALLINT UNSIGNED NOT NULL,
  `Tel` CHAR(10) NULL,
  PRIMARY KEY (`idEtablissement`),
  CONSTRAINT `fk_etablissements_villes1`
    FOREIGN KEY (`idVille`)
    REFERENCES `colloque`.`villes` (`idVille`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;

CREATE INDEX `fk_etablissements_villes1_idx` ON `colloque`.`etablissements` (`idVille` ASC);


-- -----------------------------------------------------
-- Table `colloque`.`hotels`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `colloque`.`hotels` ;

CREATE TABLE IF NOT EXISTS `colloque`.`hotels` (
  `idHotel` SMALLINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `Nom` VARCHAR(30) NOT NULL,
  `Adresse` VARCHAR(45) NOT NULL,
  `Tel` CHAR(10) NOT NULL,
  `Prix` DECIMAL(5,2) NULL,
  `Etoiles` TINYINT UNSIGNED NULL,
  `idVille` SMALLINT UNSIGNED NOT NULL,
  PRIMARY KEY (`idHotel`),
  CONSTRAINT `fk_hotels_villes1`
    FOREIGN KEY (`idVille`)
    REFERENCES `colloque`.`villes` (`idVille`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;

CREATE INDEX `fk_hotels_villes1_idx` ON `colloque`.`hotels` (`idVille` ASC);


-- -----------------------------------------------------
-- Table `colloque`.`participants`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `colloque`.`participants` ;

CREATE TABLE IF NOT EXISTS `colloque`.`participants` (
  `idParticipant` SMALLINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `Nom` VARCHAR(30) NOT NULL,
  `Prenom` VARCHAR(30) NOT NULL,
  `Adresse` VARCHAR(45) NULL,
  `idVille` SMALLINT UNSIGNED NULL,
  `Tel` CHAR(10) NULL,
  `Categorie` CHAR(5) NULL COMMENT 'choisir parmi : \'PU\', \'MCF\', \'PRAG\', \'Tech\', \'Expo\', \'Invit\', \'Visit\'',
  `Transport` CHAR(5) NULL COMMENT 'choisir parmi : \'voit\', \'taxi\', \'train\', \'avion\'',
  `idEtablissement` SMALLINT UNSIGNED NOT NULL,
  `idHotel` SMALLINT UNSIGNED NULL,
  PRIMARY KEY (`idParticipant`),
  CONSTRAINT `fk_participants_villes1`
    FOREIGN KEY (`idVille`)
    REFERENCES `colloque`.`villes` (`idVille`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_participants_etablissements1`
    FOREIGN KEY (`idEtablissement`)
    REFERENCES `colloque`.`etablissements` (`idEtablissement`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_participants_hotels1`
    FOREIGN KEY (`idHotel`)
    REFERENCES `colloque`.`hotels` (`idHotel`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;

CREATE INDEX `fk_participants_villes1_idx` ON `colloque`.`participants` (`idVille` ASC);

CREATE INDEX `fk_participants_etablissements1_idx` ON `colloque`.`participants` (`idEtablissement` ASC);

CREATE INDEX `fk_participants_hotels1_idx` ON `colloque`.`participants` (`idHotel` ASC);


-- -----------------------------------------------------
-- Table `colloque`.`categories`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `colloque`.`categories` ;

CREATE TABLE IF NOT EXISTS `colloque`.`categories` (
  `idCategorie` SMALLINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `Nom` VARCHAR(30) NOT NULL,
  PRIMARY KEY (`idCategorie`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `colloque`.`commissions`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `colloque`.`commissions` ;

CREATE TABLE IF NOT EXISTS `colloque`.`commissions` (
  `idCommission` SMALLINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `Nom` VARCHAR(45) NOT NULL,
  `Heure` DATETIME NULL,
  `Duree` SMALLINT UNSIGNED NULL COMMENT 'en minutes',
  `Salle` CHAR(5) NULL,
  `idCategorie` SMALLINT UNSIGNED NOT NULL,
  PRIMARY KEY (`idCommission`),
  CONSTRAINT `fk_commissions_categories1`
    FOREIGN KEY (`idCategorie`)
    REFERENCES `colloque`.`categories` (`idCategorie`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;

CREATE INDEX `fk_commissions_categories1_idx` ON `colloque`.`commissions` (`idCategorie` ASC);


-- -----------------------------------------------------
-- Table `colloque`.`animer`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `colloque`.`animer` ;

CREATE TABLE IF NOT EXISTS `colloque`.`animer` (
  `idCommission` SMALLINT UNSIGNED NOT NULL,
  `idParticipant` SMALLINT UNSIGNED NOT NULL,
  PRIMARY KEY (`idCommission`, `idParticipant`),
  CONSTRAINT `fk_commissions_has_participants_commissions1`
    FOREIGN KEY (`idCommission`)
    REFERENCES `colloque`.`commissions` (`idCommission`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_commissions_has_participants_participants1`
    FOREIGN KEY (`idParticipant`)
    REFERENCES `colloque`.`participants` (`idParticipant`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;

CREATE INDEX `fk_commissions_has_participants_participants1_idx` ON `colloque`.`animer` (`idParticipant` ASC);


-- -----------------------------------------------------
-- Table `colloque`.`participer`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `colloque`.`participer` ;

CREATE TABLE IF NOT EXISTS `colloque`.`participer` (
  `idCommission` SMALLINT UNSIGNED NOT NULL,
  `idParticipant` SMALLINT UNSIGNED NOT NULL,
  PRIMARY KEY (`idCommission`, `idParticipant`),
  CONSTRAINT `fk_commissions_has_participants1_commissions1`
    FOREIGN KEY (`idCommission`)
    REFERENCES `colloque`.`commissions` (`idCommission`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_commissions_has_participants1_participants1`
    FOREIGN KEY (`idParticipant`)
    REFERENCES `colloque`.`participants` (`idParticipant`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;

CREATE INDEX `fk_commissions_has_participants1_participants1_idx` ON `colloque`.`participer` (`idParticipant` ASC);


SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
