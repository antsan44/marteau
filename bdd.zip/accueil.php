<h1>Bienvenue à bord !</h1>

<p>Le Colloque National Pédagogique des départements de Génie Electrique et Informatique Industrielle est le rendez-vous annuel 
des 52&nbsp;départements GEII des <a href="http://www.iut-fr.net/">IUT de France</a>.</p>
<p>C’est l’occasion pour l’ensemble de la communauté GEII à la fois d’échanger sur les programmes, pratiques pédagogiques, techniques 
et de rencontrer de nombreux exposants venus présenter leurs nouveautés en matière de supports et d’équipements didactiques et industriels. 
Ce sont au total environ 200&nbsp;personnes qui se rencontrent sur 3&nbsp;jours.</p>
<p>La continuité de son organisation, sans interruption depuis sa création, témoigne de la force, de la cohérence et de la solidarité du 
réseau national des départements GEII. Elle prouve également le dynamisme d’une communauté qui, à l’écoute des évolutions techniques et 
sociétales depuis quatre décennies, joue un rôle moteur dans la transmission du savoir dans le domaine des nouvelles technologies, 
en perpétuelle évolution.</p>
<p>Itinérant par tradition, le colloque GEII allie travail et convivialité chaleureuse, chaque année dans une région et une ville d’accueil 
différentes. Pour cette 39<sup>ème</sup> édition, qui se déroulera les 6, 7 et 8&nbsp;juin prochain, c’est l’équipe du département GEII de l’IUT de Haguenau, 
composante de l’université de Strasbourg, qui signe son organisation et y apporte sa touche personnelle. Derrière cette équipe, c’est l’ensemble 
du personnel de l’<a href="http://iuthaguenau.unistra.fr/">IUT de Haguenau</a> ainsi que ses partenaires et notamment la 
<a href="http://www.ville-haguenau.fr/">ville Haguenau</a> qui mettent tout en œuvre pour s’inscrire dignement 
dans la droite lignée de ses excellents prédécesseurs et vous souhaitent un excellent Colloque GEII 2012 !</p>
<p>Vincent Frick</p>
<p>Chef du département GEII</p>
<p>Vice-président de l’ACD GEII</p>
<p>Président de l’organisation du colloque GEII 2012</p>