<!DOCTYPE html>
<?php
	$style=(isset($_GET['css'])?$_GET['css']:'styles') ;
	$page=(isset($_GET['page'])?$_GET['page']:'accueil') ;
?>
<html lang="fr">
	<head>
		<meta charset="utf-8" />      
		<title>Colloque GEII</title>
		<link rel="stylesheet" type="text/css" href="<?php echo $style?>.css" />
	</head>
	<body>
		<div id="menu">
			<h1>Menu</h1>
<?php
	$html ='
			<h2><a href="index.php?page=accueil&amp;style='.$style.'">Accueil</a></h2>
			<h2>Consultation</h2>
			<ul>
				<li><a href="?page=commissions&amp;style='.$style.'">Les commissions</a></li>
				<li>Les I.U.T. représentés</li>
				<li><a href="?page=exposants&amp;style='.$style.'">Les exposants partenaires</a></li>
				<li><a href="?page=participants&amp;style='.$style.'">Les participants</a></li>
				<li><a href="?page=hotels&amp;style='.$style.'">Les hôtels</a></li>
			</ul>' ;
	echo $html ;
?>
			<h2>Inscription</h2>
			<h2>Les autres colloques</h2>
				<!--     Les commentaires HTML s'écrivent entre ces deux balises    -->

			<ul>
<?php
	for($i=2010 ; $i<=2022 ; $i++) {
		if($i<>2011 AND $i<>2014) {
			echo '
				<li><a href="https://colloquegeii.iut.fr/colloque_'.$i.'">'.$i.'</a></li>' ;
		}
	}
?> 
			</ul>
		</div>
		<div id="main">
<?php
	include($page.'.php') ;
?>			
		</div>
		<div id="bottom">
<?php
	$html='
			<p> Les feuilles de styles : <a href="?page='.$page.'&amp;style=">par défaut</a> -- <a href="?page='.$page.'&amp;style=2">style 2</a></p>' ;
	echo $html ;
?>
		</div>
	</body>
</html>
