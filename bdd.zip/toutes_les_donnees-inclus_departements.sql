-- MySQL dump 10.13  Distrib 5.5.46, for debian-linux-gnu (x86_64)
--
-- Host: 127.0.0.1    Database: colloque
-- ------------------------------------------------------
-- Server version	5.5.46-0ubuntu0.14.04.2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Dumping data for table `animer`
--

-- LOCK TABLES `animer` WRITE;
/*!40000 ALTER TABLE `animer` DISABLE KEYS */;
INSERT INTO `animer` VALUES (9,2),(5,3),(2,4),(12,5),(4,6),(6,9),(10,10),(3,12),(11,14),(7,15);
/*!40000 ALTER TABLE `animer` ENABLE KEYS */;
-- UNLOCK TABLES;

--
-- Dumping data for table `categories`
--

-- LOCK TABLES `categories` WRITE;
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
INSERT INTO `categories` VALUES (1,'Anglais'),(2,'Automatismes'),(3,'Électronique'),(4,'Électrotechnique'),(5,'Expression et communication'),(6,'Informatique industrielle'),(7,'Mathématiques'),(8,'Sciences physiques'),(9,'Transversal');
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;
-- UNLOCK TABLES;

--
-- Dumping data for table `commissions`
--

-- LOCK TABLES `commissions` WRITE;
/*!40000 ALTER TABLE `commissions` DISABLE KEYS */;
INSERT INTO `commissions` VALUES (1,'Systèmes Embarqués','2013-06-06 08:30:00',120,'302',6),(2,'FPGA','2013-06-05 14:00:00',90,'302',3),(3,'Intégration','2013-06-06 16:00:00',90,'402',7),(4,'Gravure De Cartes','2013-06-07 10:30:00',90,'302',3),(5,'Utilisation de cartes cibles','2013-06-05 08:30:00',90,'303',6),(6,'Exposés et PPP','2013-06-07 10:30:00',90,'403',5),(7,'Enseignement Des Convertisseurs Statiques','2013-06-06 14:00:00',120,'302',4),(8,'Enseignement des composants de base','2013-06-07 14:00:00',120,'201',3),(9,'Le moteur à courant continu','2013-06-06 15:00:00',120,'301',4),(10,'L\'anglais Technique','2013-06-05 08:30:00',90,'302',1),(11,'Probabilités','2013-06-05 14:00:00',90,'201',7),(12,'Réseaux de terrains','2013-06-06 15:00:00',120,'202',2);
/*!40000 ALTER TABLE `commissions` ENABLE KEYS */;
-- UNLOCK TABLES;

--
-- Dumping data for table `departements`
--

-- LOCK TABLES `departements` WRITE;
/*!40000 ALTER TABLE `departements` DISABLE KEYS */;
INSERT INTO `departements` VALUES ('01','Ain','Bourg-en-Bresse'),('02','Aisne','Laon'),('03','Allier','Moulins'),('04','Alpes-de-Haute-Provence','Digne-les-Bains'),('05','Hautes-Alpes','Gap'),('06','Alpes-Maritimes','Nice'),('07','Ardèche','Privas'),('08','Ardennes','Charleville-Mézières'),('09','Ariège','Foix'),('10','Aube','Troyes'),('11','Aude','Carcassonne'),('12','Aveyron','Rodez'),('13','Bouches-du-Rhône','Marseille'),('14','Calvados','Caen'),('15','Cantal','Aurillac'),('16','Charente','Angoulême'),('17','Charente-Maritime','La Rochelle'),('18','Cher','Bourges'),('19','Corrèze','Tulle'),('21','Côte-d\'Or','Dijon'),('22','Côtes-d\'Armor','Saint-Brieuc'),('23','Creuse','Guéret'),('24','Dordogne','Périgueux'),('25','Doubs','Besançon'),('26','Drôme','Valence'),('27','Eure','Évreux'),('28','Eure-et-Loir','Chartres'),('29','Finistère','Quimper'),('2A','Corse-du-Sud','Ajaccio'),('2B','Haute-Corse','Bastia'),('30','Gard','Nîmes'),('31','Haute-Garonne','Toulouse'),('32','Gers','Auch'),('33','Gironde','Bordeaux'),('34','Hérault','Montpellier'),('35','Ille-et-Vilaine','Rennes'),('36','Indre','Châteauroux'),('37','Indre-et-Loire','Tours'),('38','Isère','Grenoble'),('39','Jura','Lons-le-Saunier'),('40','Landes','Mont-de-Marsan'),('41','Loir-et-Cher','Blois'),('42','Loire','Saint-Étienne'),('43','Haute-Loire','Le Puy-en-Velay'),('44','Loire-Atlantique','Nantes'),('45','Loiret','Orléans'),('46','Lot','Cahors'),('47','Lot-et-Garonne','Agen'),('48','Lozère','Mende'),('49','Maine-et-Loire','Angers'),('50','Manche','Saint-Lô'),('51','Marne','Châlons-en-Champagne'),('52','Haute-Marne','Chaumont'),('53','Mayenne','Laval'),('54','Meurthe-et-Moselle','Nancy'),('55','Meuse','Bar-le-Duc'),('56','Morbihan','Vannes'),('57','Moselle','Metz'),('58','Nièvre','Nevers'),('59','Nord','Lille'),('60','Oise','Beauvais'),('61','Orne','Alençon'),('62','Pas-de-Calais','Arras'),('63','Puy-de-Dôme','Clermont-Ferrand'),('64','Pyrénées-Atlantiques','Pau'),('65','Hautes-Pyrénées','Tarbes'),('66','Pyrénées-Orientales','Perpignan'),('67','Bas-Rhin','Strasbourg'),('68','Haut-Rhin','Colmar'),('69','Rhône','Lyon'),('70','Haute-Saône','Vesoul'),('71','Saône-et-Loire','Mâcon'),('72','Sarthe','Le Mans'),('73','Savoie','Chambéry'),('74','Haute-Savoie','Annecy'),('75','Paris',''),('76','Seine-Maritime','Rouen'),('77','Seine-et-Marne','Melun'),('78','Yvelines','Versailles'),('79','Deux-Sèvres','Niort'),('80','Somme','Amiens'),('81','Tarn','Albi'),('82','Tarn-et-Garonne','Montauban'),('83','Var','Toulon'),('84','Vaucluse','Avignon'),('85','Vendée','La Roche-sur-Yon'),('86','Vienne','Poitiers'),('87','Haute-Vienne','Limoges'),('88','Vosges','Épinal'),('89','Yonne','Auxerre'),('90','Territoire de Belfort','Belfort'),('91','Essonne','Évry'),('92','Hauts-de-Seine','Nanterre'),('93','Seine-Saint-Denis','Bobigny'),('94','Val-de-Marne','Créteil'),('95','Val-d\'Oise','Cergy'),('971','Guadeloupe','Basse-Terre'),('972','Martinique','Fort-de-France'),('973','Guyane','Cayenne'),('974','La Réunion','Saint-Denis'),('976','Mayotte','Mamoudzou');
/*!40000 ALTER TABLE `departements` ENABLE KEYS */;
-- UNLOCK TABLES;

--
-- Dumping data for table `etablissements`
--

-- LOCK TABLES `etablissements` WRITE;
/*!40000 ALTER TABLE `etablissements` DISABLE KEYS */;
INSERT INTO `etablissements` VALUES (1,'IUT GEII de Rennes','3 rue du Clos Courtel',15,'223234075'),(2,'IUT GEII de Rouen','rue Lavoisier',11,'235146016'),(3,'IUT GEII de Tours','Avenue Monge',1,'247367105'),(6,'CIF','Rue du Monier',13,'314245678'),(7,'IUT GEII de Belfort','11 rue Engel Gros',8,'384587700'),(8,'IUT GEII de Bordeaux 1','15 rue Naudet',19,'556845702'),(9,'IUT GEII de Cherbourg','rue Max-Pol Fouchet',21,'233014500'),(10,'IUT GEII du Havre','Place Robert Schumann',22,'232744600'),(11,'IUT GEII de Montpellier','99 avenue d\'Occitanie',23,'499585040'),(12,'IUT GEII de Nancy-Brabois','Le montet',24,'383682500'),(13,'IUT GEII de Nantes','3 rue Maréchal Joffre',25,'240306090'),(14,'IUT GEII de Lille 1','Boulevard Paul Langevin',16,'359632100'),(15,'IUT GEII de Hagueneau','30 rue du maire A.Traband',26,'388053400'),(16,'Siemens','Rue du Mont Joly',6,'321223243');
/*!40000 ALTER TABLE `etablissements` ENABLE KEYS */;
-- UNLOCK TABLES;

--
-- Dumping data for table `hotels`
--

-- LOCK TABLES `hotels` WRITE;
/*!40000 ALTER TABLE `hotels` DISABLE KEYS */;
INSERT INTO `hotels` VALUES (1,'Hôtel de la gare','15 avenue de la gare','233276768',75,'2',26),(2,'Hôtel du canard','38 place des ajoncs','237536654',50,'1',26),(3,'Hôtel Montmirail','54 rue Pompidou','237450976',86,'2',26),(4,'Hôtel Ibis style','127 avenue du Maine','233293468',99,'3',26),(5,'Hôtel Formule1','23 avenue George SAND','534545454',43,'1',26),(6,'Hôtel des voyageurs','33 rue de la Mairie','944556677',49,'1',26);
/*!40000 ALTER TABLE `hotels` ENABLE KEYS */;
-- UNLOCK TABLES;

--
-- Dumping data for table `participants`
--

-- LOCK TABLES `participants` WRITE;
/*!40000 ALTER TABLE `participants` DISABLE KEYS */;
INSERT INTO `participants` VALUES (1,'Besse','Dominique','44 rue du bois',1,'247367199','MCF','train',3,3),(2,'Cover','Harry','5 place Paul Guimard',8,'334765983','MCF','train',7,4),(3,'Térieur','Alex','234 rue des églantiers',7,'256832764','PU','voit',1,1),(4,'Bruno','Armel','43 Boulevard Heurteloup',1,'247367992','PRAG','train',3,4),(5,'Poisson','Pierre','4 Avenue des Hautes Roches',1,'247367110','PRAG','train',3,4),(6,'Oduvillage','Lydie','13 Rue Martine Caroll',10,'345321420','Expo','voit',6,2),(7,'Richard','Pierre','8 Allée des petites maisons',5,'453976543','Expo','avion',6,2),(8,'Dumoulin','Martin','45 boulevard Raspail',15,'423876549','MCF','train',1,2),(9,'Corderie','Etienne','14 rue des templiers',24,'352978652','MCF',NULL,12,1),(10,'Bigot','Hugues','3 boulevard Michel',26,'345908756','PU',NULL,15,NULL),(11,'Neau','Yann','24 Rue Leon Boyer',1,'247367108','PRAG','train',3,1),(12,'Morier','Elise','2 rue de la mare',3,'523498574','PU','train',8,6),(13,'Mairout','Jean-Claude','88 boulevard Clémenceau',21,'240994756','MCF','train',10,5),(14,'Roger','Antoine','7 impasse Gricourt',16,'354876599','MCF','train',14,5),(15,'Pahpeur','Germaine','44 rue du Maine',25,'225467899','PU','train',13,4),(16,'Aubuis','Christelle','27 rue du 8 mai 1945',22,'245986576','MCF','train',9,6),(17,'Dumont','Juliette','32 route de Paris',11,'234546576','MCF',NULL,2,3),(18,'Nibigoude','Jo','20 Allée des oliviers',10,'688779965','MCF',NULL,15,1),(19,'Thérieur','Alain','3 place du Général De Gaulle',6,'632547698','Expo','taxi',16,4);
/*!40000 ALTER TABLE `participants` ENABLE KEYS */;
-- UNLOCK TABLES;

--
-- Dumping data for table `participer`
--

-- LOCK TABLES `participer` WRITE;
/*!40000 ALTER TABLE `participer` DISABLE KEYS */;
INSERT INTO `participer` VALUES (5,1),(7,2),(6,3),(1,4),(2,4),(5,5),(6,7),(5,8),(3,9),(1,11),(10,12),(10,13),(4,15),(9,16),(11,16),(7,17),(11,17);
/*!40000 ALTER TABLE `participer` ENABLE KEYS */;
-- UNLOCK TABLES;

--
-- Dumping data for table `villes`
--

-- LOCK TABLES `villes` WRITE;
/*!40000 ALTER TABLE `villes` DISABLE KEYS */;
INSERT INTO `villes` VALUES (1,'37200','Tours','37'),(2,'36000','Chateauroux','36'),(3,'16000','Angoulème','16'),(4,'94230','Cachan','94'),(5,'38450','Grenoble','38'),(6,'74940','Annecy','74'),(7,'29238','Brest','29'),(8,'90016','Belfort','90'),(9,'13388','Marseille','13'),(10,'68093','Mulhouse','68'),(11,'76821','Rouen','76'),(12,'94410','Ville d\'Avray','94'),(13,'69627','Lyon','69'),(14,'31000','Toulouse','31'),(15,'35704','Rennes','35'),(16,'59653','Villeneuve d\'asq','59'),(19,'33175','Gradignan','33'),(20,'33000','Bordeaux','33'),(21,'50130','Octeville','50'),(22,'76610','Le Havre','76'),(23,'34000','Montpellier','34'),(24,'54601','Nancy','54'),(25,'44000','Nantes','44'),(26,'67500','Hagueneau','67');
/*!40000 ALTER TABLE `villes` ENABLE KEYS */;
-- UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2015-12-29 18:02:05
