function main()
{
	console.log("Hello, World!");
}

main();

//je te mets ca la ! tu en aura surement besoin plus tard !